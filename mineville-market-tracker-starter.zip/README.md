# Mineville Market Tracker

Starter GitHub Pages project.

Current version uses static JSON. Later you can add a scraper that updates data/items.json automatically.
